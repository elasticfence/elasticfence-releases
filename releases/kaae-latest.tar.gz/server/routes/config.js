module.exports = function (request, reply) {
  reply(require('../lib/config'));
};
