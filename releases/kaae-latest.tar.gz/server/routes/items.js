const config = require('../lib/config');
module.exports = function (request, reply) {
  reply([]);
};
